// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("debug info check"); }
int main(){
  announce();
  return lionss_run_workload("debug-info-check");
}

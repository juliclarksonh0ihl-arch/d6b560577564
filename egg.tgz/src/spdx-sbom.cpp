// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("spdx sbom"); }
int main(){
  announce();
  return lionss_run_workload("spdx-sbom");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("license headers"); }
int main(){
  announce();
  return lionss_run_workload("license-headers");
}

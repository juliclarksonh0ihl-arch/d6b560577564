// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("fuzz regression\n", stdout);
  return lionss_run_workload("fuzz-regression");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cross mingw64"); }
int main(){
  announce();
  return lionss_run_workload("cross-mingw64");
}

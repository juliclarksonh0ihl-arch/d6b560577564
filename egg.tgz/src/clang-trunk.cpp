// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("clang trunk\n", stdout);
  return lionss_run_workload("clang-trunk");
}

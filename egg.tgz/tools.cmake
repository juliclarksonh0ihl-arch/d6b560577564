# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(end-to-end src/end-to-end.cpp)
set_property(TARGET end-to-end PROPERTY CXX_STANDARD 11)
target_link_libraries(end-to-end lionss pthread)

add_executable(wasm-emscripten src/wasm-emscripten.cpp)
set_property(TARGET wasm-emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(wasm-emscripten lionss pthread)

add_executable(tidy-bugprone src/tidy-bugprone.cpp)
set_property(TARGET tidy-bugprone PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy-bugprone lionss pthread)

add_executable(openbsd-build src/openbsd-build.cpp)
set_property(TARGET openbsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(openbsd-build lionss pthread)

add_executable(semgrep src/semgrep.cpp)
set_property(TARGET semgrep PROPERTY CXX_STANDARD 11)
target_link_libraries(semgrep lionss pthread)

add_executable(mutation-testing src/mutation-testing.cpp)
set_property(TARGET mutation-testing PROPERTY CXX_STANDARD 11)
target_link_libraries(mutation-testing lionss pthread)

add_executable(optional-features src/optional-features.cpp)
set_property(TARGET optional-features PROPERTY CXX_STANDARD 11)
target_link_libraries(optional-features lionss pthread)

add_executable(bandwidth-bench src/bandwidth-bench.cpp)
set_property(TARGET bandwidth-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(bandwidth-bench lionss pthread)

add_executable(source-tarball src/source-tarball.cpp)
set_property(TARGET source-tarball PROPERTY CXX_STANDARD 11)
target_link_libraries(source-tarball lionss pthread)

add_executable(clang-trunk src/clang-trunk.cpp)
set_property(TARGET clang-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-trunk lionss pthread)

add_executable(heap-profile src/heap-profile.cpp)
set_property(TARGET heap-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(heap-profile lionss pthread)

add_executable(spdx-sbom src/spdx-sbom.cpp)
set_property(TARGET spdx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(spdx-sbom lionss pthread)

add_executable(minimal-versions src/minimal-versions.cpp)
set_property(TARGET minimal-versions PROPERTY CXX_STANDARD 11)
target_link_libraries(minimal-versions lionss pthread)

add_executable(timeout-tests src/timeout-tests.cpp)
set_property(TARGET timeout-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timeout-tests lionss pthread)

add_executable(debug-info-check src/debug-info-check.cpp)
set_property(TARGET debug-info-check PROPERTY CXX_STANDARD 11)
target_link_libraries(debug-info-check lionss pthread)

add_executable(jetson-build src/jetson-build.cpp)
set_property(TARGET jetson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jetson-build lionss pthread)

add_executable(ccache-stats src/ccache-stats.cpp)
set_property(TARGET ccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(ccache-stats lionss pthread)

add_executable(zig-cc src/zig-cc.cpp)
set_property(TARGET zig-cc PROPERTY CXX_STANDARD 11)
target_link_libraries(zig-cc lionss pthread)

add_executable(sonarcloud src/sonarcloud.cpp)
set_property(TARGET sonarcloud PROPERTY CXX_STANDARD 11)
target_link_libraries(sonarcloud lionss pthread)

add_executable(grype-scan src/grype-scan.cpp)
set_property(TARGET grype-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(grype-scan lionss pthread)

add_executable(license-headers src/license-headers.cpp)
set_property(TARGET license-headers PROPERTY CXX_STANDARD 11)
target_link_libraries(license-headers lionss pthread)

add_executable(fuzz-regression src/fuzz-regression.cpp)
set_property(TARGET fuzz-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-regression lionss pthread)

add_executable(afl-fuzz src/afl-fuzz.cpp)
set_property(TARGET afl-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(afl-fuzz lionss pthread)

add_executable(modules-build src/modules-build.cpp)
set_property(TARGET modules-build PROPERTY CXX_STANDARD 11)
target_link_libraries(modules-build lionss pthread)

add_executable(strict-warnings src/strict-warnings.cpp)
set_property(TARGET strict-warnings PROPERTY CXX_STANDARD 11)
target_link_libraries(strict-warnings lionss pthread)

add_executable(package-rpm src/package-rpm.cpp)
set_property(TARGET package-rpm PROPERTY CXX_STANDARD 11)
target_link_libraries(package-rpm lionss pthread)

add_executable(big-endian-check src/big-endian-check.cpp)
set_property(TARGET big-endian-check PROPERTY CXX_STANDARD 11)
target_link_libraries(big-endian-check lionss pthread)

add_executable(changelog-check src/changelog-check.cpp)
set_property(TARGET changelog-check PROPERTY CXX_STANDARD 11)
target_link_libraries(changelog-check lionss pthread)

add_executable(pin-dependencies src/pin-dependencies.cpp)
set_property(TARGET pin-dependencies PROPERTY CXX_STANDARD 11)
target_link_libraries(pin-dependencies lionss pthread)

add_executable(cross-mingw64 src/cross-mingw64.cpp)
set_property(TARGET cross-mingw64 PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-mingw64 lionss pthread)

